
package lab1;


public class InvalidAgeException extends Exception{
    public InvalidAgeException(String Customessage){
        super(Customessage);
    }
            
            }

