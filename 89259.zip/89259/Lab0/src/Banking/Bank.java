
package Banking;

public interface Bank {
    
    public void Deposit();
    public void Withdraw();
    public float getbalance();
}
